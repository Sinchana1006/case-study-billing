#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_ITEMS 10
#define MAX_ITEM_NAME_LEN 20
#define MAX_CUSTOMERS 100
#define MAX_CUSTOMER_NAME_LEN 20
#define MAX_USERNAME_LEN 20
#define MAX_PASSWORD_LEN 20
#define CUSTOMER_FILE "customers.txt"
#define BILL_FILE "bills.txt"

typedef struct
{
    char name[MAX_ITEM_NAME_LEN];
    int price;
} Item;

typedef struct
{
    char name[MAX_CUSTOMER_NAME_LEN];
    int id;
    int phno;
} Customer;

typedef struct
{
    char username[MAX_USERNAME_LEN];
    char password[MAX_PASSWORD_LEN];
} User;

void login(User users[], int numUsers);
void customers_details(Customer *customer);
void menu(Item items[], int num_items);
void bill(Item items[], int num_items);
void save_customer_to_file(Customer *customer);
void search_customer();

int main()
{

    User users[MAX_CUSTOMERS] = {
        {"user1", "password1"},
        {"user2", "password2"},

    };
    int numUsers = 2;

    login(users, numUsers);

    int n;
    printf("\nEnter number of customers: ");
    scanf("%d", &n);
    if (n <= 0 || n > MAX_CUSTOMERS)
    {
        printf("Invalid number of customers. Exiting...\n");
        return 1;
    }
    Customer *customers = (Customer *)malloc(n * sizeof(Customer));

    for (int i = 0; i < n; i++)
    {
        printf("\nCustomer %d\n", i + 1);
        customers_details(&customers[i]);
        save_customer_to_file(&customers[i]);
    }

    Item items[MAX_ITEMS] = {
        {"PEN", 20},
        {"POTATO", 25},
        {"BANANA", 30},
        {"GRAPES", 35},
        {"ORANGE", 20},
        {"PEAR", 40},
        {"MANGO", 200},
        {"APPLE", 150},
        {"FRUITS", 180},
        {"VEGETABLES", 250}};

    menu(items, MAX_ITEMS);
    bill(items, MAX_ITEMS);

    search_customer();

    free(customers);
    return 0;
}

void login(User users[], int numUsers)
{
    char username[MAX_USERNAME_LEN];
    char password[MAX_PASSWORD_LEN];
    int loggedIn = 0;

    while (!loggedIn)
    {
        printf("LOGIN\n");
        printf("Username: ");
        scanf("%s", username);
        printf("Password: ");
        scanf("%s", password);

        for (int i = 0; i < numUsers; ++i)
        {
            if (strcmp(users[i].username, username) == 0 && strcmp(users[i].password, password) == 0)
            {
                printf("Login successful!\n");
                loggedIn = 1;
                break;
            }
        }

        if (!loggedIn)
        {
            printf("Invalid username or password. Please try again.\n");
        }
    }
}

void customers_details(Customer *customer)
{
    printf("Enter customer's name: ");
    scanf("%s", customer->name);
    printf("Enter customer's ID: ");
    scanf("%d", &customer->id);
    printf("Enter customer's phone number: ");
    scanf("%d", &customer->phno);
}

void save_customer_to_file(Customer *customer)
{
    FILE *file = fopen(CUSTOMER_FILE, "a");
    if (file == NULL)
    {
        printf("Error opening customer file!\n");
        return;
    }
    fprintf(file, "%s %d %d\n", customer->name, customer->id, customer->phno);
    fclose(file);
}

void menu(Item items[], int num_items)
{
    printf("\nITEMS AVAILABLE:\n");
    for (int i = 0; i < num_items; i++)
    {
        printf("%d. %s - Price: %d\n", i + 1, items[i].name, items[i].price);
    }
}

void bill(Item items[], int num_items)
{
    int total_amount = 0;
    int choice;
    FILE *bill_file = fopen(BILL_FILE, "a");
    if (bill_file == NULL)
    {
        printf("Error opening bill file!\n");
        return;
    }
    do
    {
        printf("\nEnter item number to buy (0 to exit): ");
        scanf("%d", &choice);
        if (choice == 0)
        {
            break;
        }
        if (choice < 1 || choice > num_items)
        {
            printf("Invalid choice. Please enter a valid item number.\n");
            continue;
        }
        total_amount += items[choice - 1].price;
        printf("Item added to the bill: %s\n", items[choice - 1].name);
        fprintf(bill_file, "%s %d\n", items[choice - 1].name, items[choice - 1].price);
    } while (choice != 0);
    printf("Total amount to pay: %d\n", total_amount);
    fprintf(bill_file, "Total %d\n", total_amount);
    fclose(bill_file);
}

void search_customer()
{
    char search_term[MAX_CUSTOMER_NAME_LEN];
    printf("\nEnter customer name or ID to search: ");
    scanf("%s", search_term);
    FILE *file = fopen(CUSTOMER_FILE, "r");
    if (file == NULL)
    {
        printf("Error opening customer file!\n");
        return;
    }
    Customer customer;
    int found = 0;
    while (fscanf(file, "%s %d %d", customer.name, &customer.id, &customer.phno) != EOF)
    {
        if (strcmp(customer.name, search_term) == 0 || customer.id == atoi(search_term))
        {
            printf("Customer found: %s, ID: %d, Phone: %d\n", customer.name, customer.id, customer.phno);
            found = 1;
            break;
        }
    }
    if (!found)
    {
        printf("Customer not found.\n");
    }
    fclose(file);
}
