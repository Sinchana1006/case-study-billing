#ifndef STORE_H
#define STORE_H

void customers_details();
void menu();
void bill();

#endif