#include <stdio.h>
#include "store.h"

int main()
{
    char customers_name[20];
    int customers_id;
    int customer_phno;
    int n;
    printf("WELCOME TO PES STORE\n");
    printf("Enter the number of customers: ");
    scanf("%d", &n);

    for (int i = 1; i <= n; i++)
    {
        printf("Customer %d\n", i);
        customers_details();
        menu();
        bill();
    }

    return 0;
}